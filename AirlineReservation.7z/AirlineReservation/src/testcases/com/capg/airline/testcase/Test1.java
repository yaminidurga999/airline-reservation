/**
 * 
 */
package testcases.com.capg.airline.testcase;

import static org.junit.Assert.assertNotNull;

import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.airline.bean.FlightInformation;
import com.capg.airline.dao.FlightInfDaooImpl;
import com.capg.airline.exception.AirlineException;



/**
 * @author Capg
 *
 */
public class Test1 {

	static FlightInfDaooImpl flightdao=null;
	static Logger logger=Logger.getRootLogger();
	static FlightInformation flightInformation=null;

	@BeforeClass
	public static void intialize()
	{
		flightdao=new FlightInfDaooImpl();
		flightInformation=new FlightInformation();
	}
	@Test
	//------------------------ 1.Airline Book --------------------------
		/*******************************************************************************************************
					 - Function Name	:	fetchFlightNullTest()
					 - Input Parameters	:	No Parameter
					 - Return Type		:	Void
					 - Throws		    :   AirlineException
					 - Author		    :   Team 1
					 - Creation Date	:	2/4/2018
					 - Description		:	Testing the fetchFlight() method 
		 ********************************************************************************************************/
	public void fetchFlightNullTest() throws AirlineException {
		flightInformation.setFlightNo("12345");
		assertNotNull(flightdao.fetchFlight(flightInformation));
	}
}
