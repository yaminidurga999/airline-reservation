/**
 * 
 *//*
package com.capg.airline.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capg.airline.bean.AirportBean;
import com.capg.airline.bean.FlightInformation;
import com.cpag.airline.util.DBUtil;

*//**
 * @author CAPG
 *
 *//*
public class AirportDaoImpl implements IAirportDao {

	Logger logger = Logger.getRootLogger();

	Connection connection;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	*//**
	 * 
	 *//*
	public AirportDaoImpl() {
		// TODO Auto-generated constructor stub
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	@Override
	public AirportBean fetchDetails(AirportBean airportBean,FlightInformation flightInformation) {
		// TODO Auto-generated method stub
		try {
			String query="select * from flightinformation where dep_city=? and dep_date=?";
			connection = DBUtil.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, flightInformation.getDepCity());
			preparedStatement.setString(2, flightInformation.getDepDate());
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				//Data to diaplay
				System.out.println("HHHHHHHHHHHHH");
				
				
			}
		}
		catch(Exception e)
		{
			
		}
		
		return airportBean;
	}

	@Override
	public AirportBean occupancyDetails(AirportBean airportBean, FlightInformation flightInformation) {
		// TODO Auto-generated method stub
		try {
			String query="select * from flightinformation where flightno=?";
			connection = DBUtil.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, flightInformation.getFlightNo());
			
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				//Data to diaplay
				//System.out.println("ggggggggggggg");
				
				
			}
		}
		catch(Exception e)
		{
			
		}
		
		return airportBean;
	}

		
}
*/
/**
 * 
 */
package com.capg.airline.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capg.airline.bean.AirportBean;
import com.capg.airline.bean.FlightInformation;
import com.cpag.airline.util.DBUtil;

/**
 * @author CAPG
 *
 */
public class AirportDaoImpl implements IAirportDao {

	Logger logger = Logger.getRootLogger();

	Connection connection;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;

	/**
	 * 
	 */
	public AirportDaoImpl() {

		PropertyConfigurator.configure("resources//log4j.properties");
	}
	//------------------------ 1.Airline Book --------------------------
			/*******************************************************************************************************
						 - Function Name	:	fetchDetails()
						 - Input Parameters	:   airportBean,flightInformation
						 - Return Type		:	AirportBean
						 - Throws		    :   AirlineException
						 - Author		    :   Team 1
						 - Creation Date	:	2/4/2018
						 - Description		:	Fetching details of flightInformation table and show occupancy details
			 ********************************************************************************************************/
	@Override
	public AirportBean fetchDetails(AirportBean airportBean,
			FlightInformation flightInformation) {
		// TODO Auto-generated method stub
		try {

			String name = flightInformation.getAirline();

			System.out
					.println("flightinfo as follows:\n -----------------------");
			System.out.println("Airline\tFirstSeats\tBussSeats");
			String query = "select airline, sum(firstseats),sum (BussSeats)from FLIGHTINFORMATION group by airline";
			connection = DBUtil.getConnection();

			preparedStatement = connection.prepareStatement(query);

			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				// Data to diaplay

				System.out.println(resultSet.getString(1) + "\t\t"
						+ resultSet.getInt(2) + "\t" + resultSet.getInt(3));

			}
		} catch (Exception e) {
			logger.error("Flight Occupancy Details is not retreived.");
		}
		logger.info("Flight Occupancy Details retreived.");
		return airportBean;
	}
	//------------------------ 1.Airline Book --------------------------
	/*******************************************************************************************************
				 - Function Name	:	 occupancyDetails()
				 - Input Parameters	:   airportBean,flightInformation
				 - Return Type		:	AirportBean
				 - Throws		    :   AirlineException
				 - Author		    :   Team 1
				 - Creation Date	:	2/4/2018
				 - Description		:	Fetching details of flightInformation table and show occupancy details
	 ********************************************************************************************************/
	@Override
	public AirportBean occupancyDetails(AirportBean airportBean,
			FlightInformation flightInformation) {
		try {

			String query = "select airline,sum(bussSeats),sum(firstseats) from flightinformation where dep_city=? and dep_date=? group by airline";
			connection = DBUtil.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, flightInformation.getDepCity());
			preparedStatement.setString(2, flightInformation.getDepDate());

			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				System.out.println("Flight Information is as follows:");
				System.out.println("********************************");
				System.out.println("Airline Flight_No FirstSeats BussSeats");
				while (resultSet.next()) {

					System.out.println(resultSet.getString(1) + "\t"
							+ resultSet.getInt(2) + "\t\t"
							+ resultSet.getInt(3));
				}
			} else {
				logger.error("Wrong data entered by executive.");
				System.out.println("You have entered wrong data..");
			}
		} catch (Exception e) {
			logger.error("Flight Occupancy Details is not retreived.");
		}
		logger.info("Flight Occupancy Details retreived.");
		return airportBean;
	}

}
